# RDKlib samples

This repository includes samples of AWS Config Rules built with RDKlib. 

Learn about RDKlib: https://github.com/awslabs/aws-config-rdklib
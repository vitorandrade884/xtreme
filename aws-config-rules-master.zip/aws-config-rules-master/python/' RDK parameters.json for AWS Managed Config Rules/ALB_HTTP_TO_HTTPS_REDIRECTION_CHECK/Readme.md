This rule is a managed Rule. This folder will assist you on deploying the rule using the Rule Development Kit (RDK).

Managed Rules - https://docs.aws.amazon.com/config/latest/developerguide/managed-rules-by-aws-config.html

Rule Development Kit (RDK) - https://github.com/awslabs/aws-config-rdk